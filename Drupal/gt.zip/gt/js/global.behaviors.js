(function ($, Drupal) {
  Drupal.behaviors.global = {
    attach: function (context, settings) {
      
    }
  };
})(jQuery, Drupal);
